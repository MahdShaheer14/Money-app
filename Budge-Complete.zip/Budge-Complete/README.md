# Budge — complete source bundle

Everything built so far, in one folder. Read this first; it tells you what each
thing is and which one you actually want.

---

## What's in here

| Folder | What it is | Do you need it? |
|---|---|---|
| **`app-install/`** | **`Budge.apk`** — the finished, signed app. Copy to your phone and install. | **Yes, this is the app.** |
| **`android/`** | The real source code — native Kotlin, Room database, SMS receiver. | Only if you want to change the app. |
| **`web/`** | Single-file HTML prototype of the interface. Opens in any browser. | Only for looking at screens / design. |
| `legacy-java-app/` | The earlier Java + WebView version. Superseded. | No — kept for history. |

---

## The app

**File:** `app-install/Budge.apk` — 1.5 MB, signed, Android 6.0+
Version 2.0 (`versionCode 2`). Install instructions are in
`app-install/INSTALL.md`.

What it does: reads bank SMS on the phone, pulls out the amount and whether money
went out or came in, files it against the right account, and shows a running
total. No relay server, no PC, no pasting. It has **no `INTERNET` permission** —
it cannot upload anything.

### How it works

```
Bank SMS ──▶ SmsReceiver ──▶ SmsParser ──▶ Room ──▶ SmsViewModel ──▶ UI + notification
```

| File | Job |
|---|---|
| `android/java/com/budge/app/SmsReceiver.kt` | `BroadcastReceiver` for `android.provider.Telephony.SMS_RECEIVED`. Runs even with the app closed. Stitches multi-part SMS, uses `goAsync()` + coroutines. |
| `android/java/com/budge/app/parse/SmsParser.kt` | Pulls sender + body, then the amount (`Rs 421`, `Rs. 1,250.50`, `PKR 3,000`), the type (debited → DEBIT, credited → CREDIT), and the account from the sender. |
| `android/java/com/budge/app/data/Entities.kt` | `TransactionEntity` + `RuleEntity`. |
| `android/java/com/budge/app/data/BudgeDatabase.kt` | Room database, DAOs returning `Flow`, duplicate protection. |
| `android/java/com/budge/app/ui/SmsViewModel.kt` | Combines the flows so the UI updates itself. |
| `android/java/com/budge/app/SmsInboxActivity.kt` | The screen. Also does the runtime permission request. |
| `android/java/com/budge/app/SmsBackfill.kt` | Imports the last 30 days of existing SMS on first run. |
| `android/java/com/budge/app/NotificationHelper.kt` | "Payment completed" notification. |
| `android/tests/ParserTest.kt` | 61-assertion test harness for the parser. |

### The rules

- **Sender → account:** `8556` → JazzCash, `HBL` → HBL, `ASKARI` → Askari,
  `3737` → Easypaisa, `NayaPay`, `SadaPay`, anything else → Other.
  Six ship by default and you can add or edit them in the app.
- **Merchant override:** a **debit** of **exactly 421** is titled
  **`Amazon Prime Video`**, confidence 1.0. Editable, not hardcoded.
- OTPs, promos and "statement is ready" messages are rejected — they never become
  transactions.

### Permissions

```xml
<uses-permission android:name="android.permission.RECEIVE_SMS" />
<uses-permission android:name="android.permission.READ_SMS" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

Requested at runtime on first open via
`ActivityResultContracts.RequestMultiplePermissions`.

### Building it yourself

Needs JDK 17 + Android SDK (platform 34, build-tools 34.0.0).
`android/gradle-project/` holds the four Gradle files — copy them into
`android/` so it matches the standard layout:

```
android/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── local.properties          ← create it:  sdk.dir=/path/to/Android/Sdk
└── app/
    ├── build.gradle.kts
    └── src/main/             ← java/ + res/ + AndroidManifest.xml go here
```

Then `gradle assembleRelease` (AGP 8.4.0, Kotlin 1.9.24, KSP 1.9.24-1.0.20,
Room 2.6.1).

**Signing key:** `budge-release.jks` — store password `budge123`, key alias
`budge`, type JKS. Keep it: without the same key you cannot update an app that's
already installed on your phone.

```bash
apksigner sign --ks budge-release.jks --ks-pass pass:budge123 \
  --ks-key-alias budge --ks-type JKS --min-sdk-version 23 \
  --out Budge.apk Budge-unsigned.apk
```

---

## The web prototype

`web/index.html` is one self-contained file — double-click it and it runs. It
holds the full design system, budgets, people/splits, reminders and the monthly
view. It is **SMS-only**; the Gmail/email path was removed.

`web/app-core.js`, `app-ui.js`, `app-render.js` and `src.html` are the sources;
`web/build.py` inlines them into `index.html` (`python3 build.py`).

`web/server/sms_server.py` is an optional relay for the *browser* build only.
The phone app doesn't need it.

---

## Two honest notes

1. **JazzCash's shortcode is `8556`**, not `8558`. If your messages really do come
   from `8558`, edit that rule in the app — it's a two-tap change, no rebuild.
2. **`421 → Amazon Prime Video` only fires on debits.** A credit of 421 is treated
   as normal income.
